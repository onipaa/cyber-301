# 24 September 2024 Reading
I finished module 2 this morning; however, I know that the quiz is going to ask
questions like I poured over and memorized every sentance. Maybe I should get
used to memorizing everything I read. The only path to that end is to start
doing my BoM memorization like I have wanted to but did not. I need to get my
mind to the point that I really do memorize everything after a 1 time through
the material. I used to be much better, but COVID 3x and Cancer left me scatter
brained. Many times, it feels like my mind is going in several directions at
once.


## Module 2
Page 56 (review and glossary of terms) VIP page. Most of this module was about
"frameworks" and "regulations."

**adversary tactics, techniques, and procedures (TTP)** A database of the behavior of threat actors and how they orchestrate and manage attacks.

**benchmark/secure configuration guides** Guidelines for configuring a device or software usually distributed by hardware manufacturers and software developers.

**benchmark/secure configuration guides** Guidelines for configuring a device or software usually distributed by hardware manufacturers and software developers.

**Blue Team** A penetration testing team that monitors for Red Team attacks and shores up defenses as necessary.



## Module 3

## Module 4 (partial)
